package com.jsp;

//import java.sql.DriverManager;
//import java.sql.SQLException;

import org.postgresql.Driver;

public class RegisterDriverSW {
public static void main(String[] args) {
	// register driver s/w
////	Driver d = new Driver();
//	try {
//		DriverManager.registerDriver(d);
//	} catch (SQLException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
	
	try {
		Class.forName("org.postgresql.Driver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
