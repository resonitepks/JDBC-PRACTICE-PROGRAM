package com.jsp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class StatementObject {
	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
			try {
				Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbcmorningbatch", "postgres", "root");
//					3. create  Statement Object
				Statement stmt=con.createStatement();
				//4.execute query
//				boolean b= stmt.execute("insert into Emp values (103,'pratik', 'pks@gmail.com','2456',23, 'male','123456')");
				boolean b= stmt.execute("insert into Bank values (103,'pratik','p.o',2456,'male');");
				System.out.println(b);
				System.out.println("data inserted");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
