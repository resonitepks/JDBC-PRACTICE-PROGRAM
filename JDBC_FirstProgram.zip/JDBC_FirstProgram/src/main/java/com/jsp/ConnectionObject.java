package com.jsp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionObject {
	public static void main(String[] args) {
		try {
			//1. load the driver
			Class.forName("org.postgresql.Driver");
			//2.create connection object
			try {
				Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbcmorningbatch", "postgres", "root");
				System.out.println(con);//org.postgresql.jdbc.PgConnection@13c27452
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
