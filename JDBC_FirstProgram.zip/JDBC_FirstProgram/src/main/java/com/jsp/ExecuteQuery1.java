package com.jsp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ExecuteQuery1 {
public static void main(String[] args) {
	try {
		Class.forName("org.postgresql.Driver");
		try {
			Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbcmorningbatch", "postgres", "root");
			//3.create Statement object
			Statement stmt=con.createStatement();
			ResultSet rs =stmt.executeQuery("select *from emp");
			while (rs.next()) {
				int empid = rs.getInt(1);
				String ename= rs.getString(2);
				String email= rs.getString(3);
				long mob= rs.getLong("mob");
				System.out.println(empid+" "+ename+" "+email+" "+mob);
				
				}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
