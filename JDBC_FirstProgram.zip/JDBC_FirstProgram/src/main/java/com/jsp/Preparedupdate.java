package com.jsp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Preparedupdate {
	public static void main(String[] args) {
		try {
			//1
			Class.forName("org.postgresql.Driver");
			//2

  Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbcmorningbatch", "postgres", "root");
  //
  PreparedStatement pstmt =con.prepareStatement("update emp set name=? where id=?");// compilation
  // set
  pstmt.setString(1, "sid");
  pstmt.setInt(2, 108);
  
  // update emp set name='sid' where id=108
 int n =pstmt.executeUpdate();
  System.out.println(n);
  con.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}

	
