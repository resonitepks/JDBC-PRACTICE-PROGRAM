package com.jsp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PreparedStatemtclass {
 public static void main(String[] args) {
	 //1
	 try {
		Class.forName("org.postgresql.Driver");
		//2

Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbcmorningbatch", "postgres", "root");
//3
PreparedStatement pstmt =con.prepareStatement("insert into emp values(?,?,?,?,?,?,?)");//======>compilation
//set 
pstmt.setInt(1, 108);
pstmt.setString(2, "Bhabhi lover");
pstmt.setString(3, "b@gmail.com");
pstmt.setString(4, "123456");
pstmt.setInt(5, 25);
pstmt.setString(6, "Male");
pstmt.setLong(7, 987658);
// insert into emp values(108,'Bhabhi lover','b@gmail.com','123456',25,'Male',987658)
//execute
int  n =pstmt.executeUpdate();
System.out.println(n);
//
con.close();

} catch (ClassNotFoundException| SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
