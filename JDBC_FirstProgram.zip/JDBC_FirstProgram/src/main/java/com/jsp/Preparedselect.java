package com.jsp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Preparedselect {
 public static void main(String[] args) {
	try {

		Class.forName("org.postgresql.Driver");
		//2

Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbcmorningbatch", "postgres", "root");
//3
PreparedStatement pstmt =con.prepareStatement("select* from emp where id=?");//======>compilation
// set
pstmt.setInt(1, 108);
//select* from emp where id=108
   ResultSet  rs= pstmt.executeQuery();
    while(rs.next()) {
    	System.out.println(rs.getInt(1)+" "+ rs.getString(2)+" "+ rs.getString(3)+" "+rs.getString(4)
    	 +" "+rs.getInt(5)+" "+rs.getString(6)+" " +rs.getLong(7));
    }
    // 
    con.close();
	} catch (Exception e) {
		// TODO: handle exception
	}
}
}
