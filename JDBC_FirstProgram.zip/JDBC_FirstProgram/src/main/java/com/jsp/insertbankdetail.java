package com.jsp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class insertbankdetail {
	public static void main(String[] args) {
		// 1 load driver software
		try {
			Class.forName("org.postgresql.Driver");
			//2 create connection object
			try {
				Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbcmorningbatch", "postgres", "root");
				//3 create statement object
				Statement stmt=con.createStatement();
				//4.execute query
				//boolean b= stmt.execute("insert into bank values (103,'pratik','p.o',2456,'male')");
				boolean b =stmt.execute("insert into bank values (107,'riki','cfo',4457,'male'),(116,'pik','clerk',4156,'male')");
				
				System.out.println(b);
				System.out.println("data inserted");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
